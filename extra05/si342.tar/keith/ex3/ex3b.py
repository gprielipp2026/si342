from ex3a import *

# Bob wrote this
def bar(s):
    A = s.split(":")
    return foo(A[0],A[1])
