# Alice wrote this.
def foo(x,y):
    print("!!! Starting foo!")
    res = x * y
    print("!!! Exiting  foo!")
    return res

    
