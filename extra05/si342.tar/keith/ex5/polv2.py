def printOnLinesV2(L):
    for x in L:
        print(x)
