def printOnLinesV1(L):
    for i in range(len(L)):
        print(L[i])
        
        

