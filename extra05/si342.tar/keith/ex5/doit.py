def doit(L):
    for i in range(len(L)):
        print(" "*i + L[i]) # str s * int i => i copies of s
