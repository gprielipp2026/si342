public class Ex2 {
public static int foo(int x) {
  int res = x + y;
  return res;
}

  public static void main(String[] args) {
    int r = foo(42);
    System.out.println(r);
  }
}
