def foo(x):
    res = x + y
    return res

foo(42)
