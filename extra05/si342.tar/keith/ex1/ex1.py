def modadd(x,y,n):
    print("in modadd!")
    res = x + y % n
    return res

k = modadd(4,5,0)
print(k)

